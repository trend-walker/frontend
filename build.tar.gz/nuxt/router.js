import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _6d9615fe = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _1c7e76ea = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages_inspire" */))
const _29d1b934 = () => interopDefault(import('..\\pages\\latest.vue' /* webpackChunkName: "pages_latest" */))
const _18ae7abc = () => interopDefault(import('..\\pages\\nuxt.vue' /* webpackChunkName: "pages_nuxt" */))
const _06fd6e85 = () => interopDefault(import('..\\pages\\Todo.vue' /* webpackChunkName: "pages_Todo" */))
const _5958366a = () => interopDefault(import('..\\pages\\trendword\\index.vue' /* webpackChunkName: "pages_trendword_index" */))
const _72d0ae5d = () => interopDefault(import('..\\pages\\daily\\_index.vue' /* webpackChunkName: "pages_daily__index" */))
const _c97705ca = () => interopDefault(import('..\\pages\\trendword\\_trendWordId.vue' /* webpackChunkName: "pages_trendword__trendWordId" */))
const _6e791894 = () => interopDefault(import('..\\pages\\daily\\_date\\_trendWordId.vue' /* webpackChunkName: "pages_daily__date__trendWordId" */))
const _e5641e7a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

if (process.client) {
  if ('scrollRestoration' in window.history) {
    window.history.scrollRestoration = 'manual'

    // reset scrollRestoration to auto when leaving page, allowing page reload
    // and back-navigation from other pages to use the browser to restore the
    // scrolling position.
    window.addEventListener('beforeunload', () => {
      window.history.scrollRestoration = 'auto'
    })

    // Setting scrollRestoration to manual again when returning to this page.
    window.addEventListener('load', () => {
      window.history.scrollRestoration = 'manual'
    })
  }
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/about",
      component: _6d9615fe,
      name: "about"
    }, {
      path: "/inspire",
      component: _1c7e76ea,
      name: "inspire"
    }, {
      path: "/latest",
      component: _29d1b934,
      name: "latest"
    }, {
      path: "/nuxt",
      component: _18ae7abc,
      name: "nuxt"
    }, {
      path: "/Todo",
      component: _06fd6e85,
      name: "Todo"
    }, {
      path: "/trendword",
      component: _5958366a,
      name: "trendword"
    }, {
      path: "/daily/:index",
      component: _72d0ae5d,
      name: "daily"
    }, {
      path: "/trendword/:trendWordId",
      component: _c97705ca,
      name: "trendword-trendWordId"
    }, {
      path: "/daily/:date/:trendWordId?",
      component: _6e791894,
      name: "daily-date-trendWordId"
    }, {
      path: "/",
      component: _e5641e7a,
      name: "index"
    }],

    fallback: false
  })
}
