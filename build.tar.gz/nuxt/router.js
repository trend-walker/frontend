import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _2a0af83d = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages_about" */))
const _6486130a = () => interopDefault(import('..\\pages\\inspire.vue' /* webpackChunkName: "pages_inspire" */))
const _8582edf2 = () => interopDefault(import('..\\pages\\latest.vue' /* webpackChunkName: "pages_latest" */))
const _01ff1c83 = () => interopDefault(import('..\\pages\\nuxt.vue' /* webpackChunkName: "pages_nuxt" */))
const _1553c866 = () => interopDefault(import('..\\pages\\Todo.vue' /* webpackChunkName: "pages_Todo" */))
const _75cc726a = () => interopDefault(import('..\\pages\\trendword\\index.vue' /* webpackChunkName: "pages_trendword_index" */))
const _621ae19c = () => interopDefault(import('..\\pages\\daily\\_index.vue' /* webpackChunkName: "pages_daily__index" */))
const _73d5ad86 = () => interopDefault(import('..\\pages\\trend\\_id.vue' /* webpackChunkName: "pages_trend__id" */))
const _ac1a24cc = () => interopDefault(import('..\\pages\\trendword\\_trendWordId.vue' /* webpackChunkName: "pages_trendword__trendWordId" */))
const _4678bed7 = () => interopDefault(import('..\\pages\\daily\\_date\\_trendWordId.vue' /* webpackChunkName: "pages_daily__date__trendWordId" */))
const _49c2d302 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

if (process.client) {
  if ('scrollRestoration' in window.history) {
    window.history.scrollRestoration = 'manual'

    // reset scrollRestoration to auto when leaving page, allowing page reload
    // and back-navigation from other pages to use the browser to restore the
    // scrolling position.
    window.addEventListener('beforeunload', () => {
      window.history.scrollRestoration = 'auto'
    })

    // Setting scrollRestoration to manual again when returning to this page.
    window.addEventListener('load', () => {
      window.history.scrollRestoration = 'manual'
    })
  }
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/about",
      component: _2a0af83d,
      name: "about"
    }, {
      path: "/inspire",
      component: _6486130a,
      name: "inspire"
    }, {
      path: "/latest",
      component: _8582edf2,
      name: "latest"
    }, {
      path: "/nuxt",
      component: _01ff1c83,
      name: "nuxt"
    }, {
      path: "/Todo",
      component: _1553c866,
      name: "Todo"
    }, {
      path: "/trendword",
      component: _75cc726a,
      name: "trendword"
    }, {
      path: "/daily/:index",
      component: _621ae19c,
      name: "daily"
    }, {
      path: "/trend/:id?",
      component: _73d5ad86,
      name: "trend-id"
    }, {
      path: "/trendword/:trendWordId",
      component: _ac1a24cc,
      name: "trendword-trendWordId"
    }, {
      path: "/daily/:date/:trendWordId?",
      component: _4678bed7,
      name: "daily-date-trendWordId"
    }, {
      path: "/",
      component: _49c2d302,
      name: "index"
    }],

    fallback: false
  })
}
