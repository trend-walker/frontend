import Vue from 'vue'

import Vuetify from 'vuetify/lib'

Vue.use(Vuetify)

export default (ctx) => {
  const vuetify = new Vuetify({"theme":{"dark":false,"themes":{"dark":{"primary":"#1976d2","accent":"#424242","secondary":"#ff8f00","info":"#26a69a","warning":"#ffc107","error":"#dd2c00","success":"#00e676"}}}})

  ctx.app.vuetify = vuetify
  ctx.$vuetify = vuetify.framework
}
